    </main>

    <footer class="page-footer">
      <div class="footer-copyright text-center py-3">Copyright 2018, Software Engineering Course, ASUENG.</div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./js/jquery.min.js">
    <script src="./js/popper.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
  </body>
</html>
