<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="./images/user-graduate.ico">

        <title>SIS - School Information System</title>

        <!-- Font Awesome -->
        <link href="./css/Font Awesome/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Bootstrap core CSS -->
        <link href="./css/Bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css">

        <!-- Custom styles for this template -->
        <link href="./css/sticky-footer-navbar.css" rel="stylesheet" type="text/css">
    </head>  